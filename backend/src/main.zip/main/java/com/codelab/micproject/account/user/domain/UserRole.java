package com.codelab.micproject.account.user.domain;

public enum UserRole { USER, CONSULTANT, ADMIN }