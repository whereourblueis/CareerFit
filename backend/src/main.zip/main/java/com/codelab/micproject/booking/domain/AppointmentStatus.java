package com.codelab.micproject.booking.domain;

public enum AppointmentStatus { REQUESTED, APPROVED, CANCELLED, DONE }