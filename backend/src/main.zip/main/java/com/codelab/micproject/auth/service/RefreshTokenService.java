//package com.codelab.micproject.auth.service;
//
//
//import com.codelab.micproject.auth.domain.RefreshToken;
//import com.codelab.micproject.auth.repository.RefreshTokenRepository;
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;
//
//
//import java.time.Duration;
//import java.time.Instant;
//import java.util.UUID;
//
//
//@Service
//public class RefreshTokenService {
//
//
//    private final RefreshTokenRepository repo;
//
//
//    public RefreshTokenService(RefreshTokenRepository repo) {
//        this.repo = repo;
//    }
//
//
//    /** 유저당 1개 정책 — 기존 토큰 제거 후 새로 발급 */
//    @Transactional
//    public RefreshToken issue(Long userId, Duration ttl) {
//        repo.deleteByUserId(userId);
//        String token = UUID.randomUUID() + "." + UUID.randomUUID();
//        Instant expires = Instant.now().plus(ttl);
//        RefreshToken rt = new RefreshToken(userId, token, expires);
//        return repo.save(rt);
//    }
//
//
//    public RefreshToken find(String token) {
//        return repo.findByToken(token).orElse(null);
//    }
//
//
//    @Transactional
//    public void revokeAll(Long userId) {
//        repo.deleteByUserId(userId);
//    }
//}