package com.codelab.micproject.payment.domain;

public enum RefundStatus { REQUESTED, COMPLETED, REJECTED }