// common/util/CookieUtils.java
package com.codelab.micproject.common.util;

import jakarta.servlet.http.*;
import java.util.Arrays;
import java.util.Optional;

public class CookieUtils {

    public static Optional<String> getCookieValue(HttpServletRequest req, String name) {
        Cookie[] cookies = req.getCookies();
        if (cookies == null) return Optional.empty();
        return Arrays.stream(cookies)
                .filter(c -> c.getName().equals(name))
                .map(Cookie::getValue)
                .findFirst();
    }

    public static void addHttpOnlyCookie(HttpServletResponse res, String name, String value,
                                         int maxAge, String domain, boolean secure, String sameSite) {
        Cookie cookie = new Cookie(name, value);
        cookie.setHttpOnly(true);
        cookie.setPath("/");
        cookie.setMaxAge(maxAge);
        if (domain != null && !domain.isBlank()) cookie.setDomain(domain);
        cookie.setSecure(secure);
        res.addHeader("Set-Cookie", buildSetCookie(cookie, sameSite));
    }

    // SameSite 속성 지원을 위해 수동 빌드
    private static String buildSetCookie(Cookie c, String sameSite) {
        StringBuilder sb = new StringBuilder();
        sb.append(c.getName()).append("=").append(c.getValue()).append("; Path=").append(c.getPath());
        if (c.getDomain() != null) sb.append("; Domain=").append(c.getDomain());
        if (c.getMaxAge() >= 0) sb.append("; Max-Age=").append(c.getMaxAge());
        if (c.getSecure()) sb.append("; Secure");
        sb.append("; HttpOnly");
        if (sameSite != null && !sameSite.isBlank()) sb.append("; SameSite=").append(sameSite);
        return sb.toString();
    }

    public static void deleteCookie(HttpServletResponse res, String name, String domain, boolean secure, String sameSite) {
        addHttpOnlyCookie(res, name, "", 0, domain, secure, sameSite);
    }
}
