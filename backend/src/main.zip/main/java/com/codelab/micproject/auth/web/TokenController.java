// auth/web/TokenController.java
package com.codelab.micproject.auth.web;

import com.codelab.micproject.account.user.domain.User;
import com.codelab.micproject.account.user.repository.UserRepository;
import com.codelab.micproject.auth.domain.RefreshToken;
import com.codelab.micproject.auth.repository.RefreshTokenRepository;
import com.codelab.micproject.common.util.CookieUtils;
import com.codelab.micproject.security.jwt.JwtTokenProvider;

import jakarta.servlet.http.*;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;

/**
 * /api/auth/refresh : REFRESH_TOKEN 쿠키가 유효하면 ACCESS_TOKEN 재발급
 */
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class TokenController {

    private final JwtTokenProvider tokenProvider;
    private final RefreshTokenRepository refreshTokenRepository;
    private final UserRepository userRepository;

    @Value("${app.cookie.domain:}")
    private String cookieDomain;
    @Value("${app.cookie.secure:false}")
    private boolean cookieSecure;
    @Value("${app.cookie.same-site:Lax}")
    private String sameSite;

    @PostMapping("/refresh")
    public ResponseEntity<?> refresh(HttpServletRequest req, HttpServletResponse res) {
        String rt = CookieUtils.getCookieValue(req, "REFRESH_TOKEN").orElse(null);
        if (rt == null) return ResponseEntity.status(401).body("no refresh token");

        return refreshTokenRepository.findById(rt)
                .filter(r -> r.getExpiresAt().isAfter(LocalDateTime.now()))
                .map(r -> {
                    User user = userRepository.findById(r.getUserId()).orElse(null);
                    if (user == null) return ResponseEntity.status(401).body("user not found");
                    String newAccess = tokenProvider.createAccessToken(user);
                    CookieUtils.addHttpOnlyCookie(res, "ACCESS_TOKEN", newAccess, 60*60, cookieDomain, cookieSecure, sameSite);
                    return ResponseEntity.ok().build();
                })
                .orElseGet(() -> ResponseEntity.status(401).body("invalid refresh token"));
    }

    @PostMapping("/logout-all")
    public ResponseEntity<?> logoutAll(HttpServletRequest req, HttpServletResponse res) {
        String rt = CookieUtils.getCookieValue(req, "REFRESH_TOKEN").orElse(null);
        if (rt != null) {
            refreshTokenRepository.findById(rt).ifPresent(r -> {
                refreshTokenRepository.deleteByUserId(r.getUserId());
            });
        }
        CookieUtils.deleteCookie(res, "ACCESS_TOKEN", cookieDomain, cookieSecure, sameSite);
        CookieUtils.deleteCookie(res, "REFRESH_TOKEN", cookieDomain, cookieSecure, sameSite);
        return ResponseEntity.ok().build();
    }
}
