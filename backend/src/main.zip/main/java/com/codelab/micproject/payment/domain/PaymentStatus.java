package com.codelab.micproject.payment.domain;

public enum PaymentStatus {
    READY, SUCCESS, FAILED
}