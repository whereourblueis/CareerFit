package com.codelab.micproject.security.oauth2;

import com.codelab.micproject.account.user.domain.User;
import com.codelab.micproject.account.user.repository.UserRepository;
import com.codelab.micproject.auth.domain.RefreshToken;
import com.codelab.micproject.auth.repository.RefreshTokenRepository;
import com.codelab.micproject.common.util.CookieUtils;
import com.codelab.micproject.security.jwt.JwtTokenProvider;
import jakarta.servlet.http.*;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.ZoneId;

/**
 * 흐름:
 * 1) OAuth2 성공 → UserPrincipal에서 userId 추출
 * 2) AT/RT 발급 → DB에 RT 저장
 * 3) HttpOnly 쿠키에 AT/RT 저장(설정 기반 만료)
 * 4) 프론트로 리다이렉트(설정 기반)
 */
@Component
@RequiredArgsConstructor
public class OAuth2AuthenticationSuccessHandler implements AuthenticationSuccessHandler {

    private final JwtTokenProvider tokenProvider;
    private final UserRepository userRepository;
    private final RefreshTokenRepository refreshTokenRepository;

    // 쿠키 설정
    @Value("${app.cookie.domain:}")   private String cookieDomain; // localhost면 빈 값 권장
    @Value("${app.cookie.secure:false}") private boolean cookieSecure;
    @Value("${app.cookie.same-site:Lax}") private String sameSite;

    // 리다이렉트 URL(로컬 기본값)
    @Value("${app.oauth2.success-redirect:http://localhost:3000/social/success}")
    private String successRedirect;

    @Override
    public void onAuthenticationSuccess(HttpServletRequest req, HttpServletResponse res, Authentication authentication) throws IOException {
        UserPrincipal principal = (UserPrincipal) authentication.getPrincipal();
        User user = userRepository.findById(principal.getId()).orElseThrow();

        // 1) 토큰 발급
        String access = tokenProvider.createAccessToken(user);
        String refresh = tokenProvider.createRefreshToken(user.getId());

        // 2) RT 저장 (만료는 provider 설정값 기준)
        long rtDays = tokenProvider.getRefreshExpDays();
        LocalDateTime rtExp = LocalDateTime.now(ZoneId.systemDefault()).plusDays(rtDays);
        refreshTokenRepository.deleteByUserId(user.getId());
        refreshTokenRepository.save(RefreshToken.builder()
                .token(refresh)
                .userId(user.getId())
                .expiresAt(rtExp)
                .build());

        // 3) 쿠키(maxAge: 초 단위) — 설정값에서 파생
        int accessMaxAge = (int) (tokenProvider.getAccessExpMin() * 60);
        int refreshMaxAge = (int) (rtDays * 24 * 60 * 60);

        CookieUtils.addHttpOnlyCookie(res, "ACCESS_TOKEN", access, accessMaxAge, cookieDomain, cookieSecure, sameSite);
        CookieUtils.addHttpOnlyCookie(res, "REFRESH_TOKEN", refresh, refreshMaxAge, cookieDomain, cookieSecure, sameSite);

        // 4) 프론트 리다이렉트
        res.sendRedirect(successRedirect);
    }
}
