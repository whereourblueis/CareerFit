package com.codelab.micproject.booking.dto;

public enum SessionBundle { ONE(1), THREE(3), FIVE(5);
    public final int count; SessionBundle(int c){this.count=c;} }
