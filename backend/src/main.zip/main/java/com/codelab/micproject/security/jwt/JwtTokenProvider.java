package com.codelab.micproject.security.jwt;

import com.codelab.micproject.account.user.domain.User;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Date;

/**
 * JJWT 0.12.x 전용 구현.
 * - 프로퍼티 키를 app.jwt.* → 없으면 jwt.* 로 fallback 지원.
 * - secret 최소 32바이트 검증(HS256 안전성).
 */
@Component
public class JwtTokenProvider {

    private final String issuer;
    private final long accessExpMin;
    private final long refreshExpDays;
    private final SecretKey key;

    public JwtTokenProvider(
            @Value("${app.jwt.issuer:${jwt.issuer}}") String issuer,
            @Value("${app.jwt.secret:${jwt.secret}}") String secret,
            @Value("${app.jwt.access-exp-min:${jwt.access-exp-min:60}}") long accessExpMin,
            @Value("${app.jwt.refresh-exp-days:${jwt.refresh-exp-days:14}}") long refreshExpDays
    ) {
        if (secret == null || secret.getBytes(StandardCharsets.UTF_8).length < 32) {
            throw new IllegalStateException("app.jwt.secret must be >= 32 bytes (UTF-8).");
        }
        this.issuer = issuer;
        this.accessExpMin = accessExpMin;
        this.refreshExpDays = refreshExpDays;
        this.key = Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
    }

    public String createAccessToken(User user) {
        Instant now = Instant.now();
        Instant exp = now.plus(accessExpMin, ChronoUnit.MINUTES);

        String role = (user.getRole() != null) ? user.getRole().name() : "USER";

        return Jwts.builder()
                .issuer(issuer)
                .subject(String.valueOf(user.getId()))
                .claim("email", user.getEmail())
                .claim("role", role)
                .issuedAt(Date.from(now))
                .expiration(Date.from(exp))
                .signWith(key)
                .compact();
    }

    public String createRefreshToken(Long userId) {
        Instant now = Instant.now();
        Instant exp = now.plus(refreshExpDays, ChronoUnit.DAYS);

        return Jwts.builder()
                .issuer(issuer)
                .subject(String.valueOf(userId))
                .issuedAt(Date.from(now))
                .expiration(Date.from(exp))
                .signWith(key)
                .compact();
    }

    public Jws<Claims> parse(String token) {
        return Jwts.parser()
                .verifyWith(key)
                .build()
                .parseSignedClaims(token);
    }

    public Long getUserId(String token) {
        return Long.valueOf(parse(token).getPayload().getSubject());
    }

    public long getRefreshExpDays() { return refreshExpDays; } // SuccessHandler에서 쿠키 만료 계산에 사용
    public long getAccessExpMin() { return accessExpMin; }
}
