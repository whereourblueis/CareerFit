package com.codelab.micproject.account.user.service;

import com.codelab.micproject.account.user.domain.EmailVerificationToken;
import com.codelab.micproject.account.user.domain.User;
import com.codelab.micproject.account.user.repository.EmailVerificationTokenRepository;
import com.codelab.micproject.account.user.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class EmailVerificationService {

    private static final Logger log = LoggerFactory.getLogger(EmailVerificationService.class);

    private final EmailVerificationTokenRepository tokenRepo;
    private final UserRepository userRepo;

    @Transactional
    public void sendVerificationEmail(String email, String baseVerifyUrl) {
        User user = userRepo.findByEmail(email).orElseThrow(() -> new IllegalArgumentException("user not found"));

        String token = UUID.randomUUID().toString().replace("-", "");
        EmailVerificationToken evt = EmailVerificationToken.builder()
                .token(token)
                .user(user)
                .expiresAt(Instant.now().plus(1, ChronoUnit.DAYS))
                .used(false)
                .build();
        tokenRepo.save(evt);

        String link = baseVerifyUrl + "?token=" + token;
        log.info("[DEV] Email verification link for {} -> {}", email, link);
    }

    @Transactional
    public void verify(String token) {
        EmailVerificationToken evt = tokenRepo.findByToken(token).orElseThrow(() -> new IllegalArgumentException("invalid token"));
        if (evt.isUsed() || evt.getExpiresAt().isBefore(Instant.now())) {
            throw new IllegalStateException("token expired/used");
        }
        User user = evt.getUser();
        user.setEnabled(true);
        evt.setUsed(true);
        tokenRepo.save(evt);
    }
}
