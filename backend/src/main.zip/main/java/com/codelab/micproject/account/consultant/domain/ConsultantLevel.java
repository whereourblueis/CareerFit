package com.codelab.micproject.account.consultant.domain;


public enum ConsultantLevel { JUNIOR, SENIOR, EXECUTIVE }