// auth/web/AuthController.java
package com.codelab.micproject.auth.web;

import com.codelab.micproject.account.user.domain.User;
import com.codelab.micproject.account.user.repository.UserRepository;
import com.codelab.micproject.auth.dto.UserProfileDto;
import com.codelab.micproject.common.util.CookieUtils;
import com.codelab.micproject.security.jwt.JwtTokenProvider;

import jakarta.servlet.http.*;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final JwtTokenProvider tokenProvider;
    private final UserRepository userRepository;

    @Value("${app.cookie.domain:}")
    private String cookieDomain;
    @Value("${app.cookie.secure:false}")
    private boolean cookieSecure;
    @Value("${app.cookie.same-site:Lax}")
    private String sameSite;

    /**
     * 현재 사용자 조회(쿠키/헤더의 AccessToken 기준)
     */
    @GetMapping("/me")
    public ResponseEntity<?> me(HttpServletRequest req) {
        String token = CookieUtils.getCookieValue(req, "ACCESS_TOKEN").orElse(null);
        if (token == null) return ResponseEntity.ok().body(null);
        try {
            Long userId = tokenProvider.getUserId(token);
            User u = userRepository.findById(userId).orElse(null);
            if (u == null) return ResponseEntity.ok().body(null);
            return ResponseEntity.ok(UserProfileDto.builder()
                    .id(u.getId()).email(u.getEmail()).name(u.getName())
                    .profileImage(u.getProfileImage()).role(u.getRole()).provider(u.getProvider())
                    .build());
        } catch (Exception e) {
            return ResponseEntity.ok().body(null);
        }
    }

    /**
     * 로그아웃: 쿠키 삭제 + (선택) 서버단 RT 무효화는 TokenController에서 처리
     */
    @PostMapping("/logout")
    public ResponseEntity<?> logout(HttpServletResponse res) {
        CookieUtils.deleteCookie(res, "ACCESS_TOKEN", cookieDomain, cookieSecure, sameSite);
        CookieUtils.deleteCookie(res, "REFRESH_TOKEN", cookieDomain, cookieSecure, sameSite);
        return ResponseEntity.ok().build();
    }
}
