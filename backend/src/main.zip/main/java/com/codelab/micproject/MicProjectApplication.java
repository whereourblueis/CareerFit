package com.codelab.micproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicProjectApplication {
    public static void main(String[] args) {
        SpringApplication.run(MicProjectApplication.class, args);
    }
}