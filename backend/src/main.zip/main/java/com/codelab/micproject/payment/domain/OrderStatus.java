package com.codelab.micproject.payment.domain;

public enum OrderStatus {
    CREATED, PAID, CANCELED
}
