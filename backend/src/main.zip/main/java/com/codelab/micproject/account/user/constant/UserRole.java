//package com.codelab.micproject.account.user.constant;
//
//public enum UserRole { USER, CONSULTANT, ADMIN }
