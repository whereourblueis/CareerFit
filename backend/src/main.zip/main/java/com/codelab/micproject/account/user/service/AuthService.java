package com.codelab.micproject.account.user.service;

import com.codelab.micproject.account.user.domain.AuthProvider;
import com.codelab.micproject.account.user.domain.User;
import com.codelab.micproject.account.user.domain.UserRole;
import com.codelab.micproject.account.user.dto.LoginRequest;
import com.codelab.micproject.account.user.dto.SignupRequest;
import com.codelab.micproject.account.user.repository.UserRepository;
import com.codelab.micproject.security.jwt.JwtTokenProvider;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder encoder;
    private final JwtTokenProvider tokenProvider;

    @Transactional
    public void signup(SignupRequest req) {
        userRepository.findByEmail(req.email()).ifPresent(u -> {
            throw new IllegalArgumentException("이미 가입된 이메일입니다.");
        });

        User user = User.builder()
                .email(req.email())
                .password(encoder.encode(req.password()))
                .name(req.name())
                .role(UserRole.USER)
                .provider(AuthProvider.LOCAL)
                .enabled(false) // 이메일 인증 전까지 비활성
                .build();

        userRepository.save(user);
    }

    @Transactional(readOnly = true)
    public String login(LoginRequest req) {
        var user = userRepository.findByEmail(req.email())
                .orElseThrow(() -> new BadCredentialsException("잘못된 자격증명"));
        if (!encoder.matches(req.password(), user.getPassword())) {
            throw new BadCredentialsException("잘못된 자격증명");
        }
        if (!user.isEnabled()) {
            throw new BadCredentialsException("이메일 인증을 완료해 주세요.");
        }
        return tokenProvider.createAccessToken(user);
    }
}
