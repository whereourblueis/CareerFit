package com.codelab.micproject.account.user.domain;

public enum AuthProvider { LOCAL, GOOGLE, KAKAO, NAVER }