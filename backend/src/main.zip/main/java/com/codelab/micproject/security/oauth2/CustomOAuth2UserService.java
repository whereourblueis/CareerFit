// security/oauth2/CustomOAuth2UserService.java
package com.codelab.micproject.security.oauth2;

import com.codelab.micproject.account.user.domain.AuthProvider;
import com.codelab.micproject.account.user.domain.User;
import com.codelab.micproject.account.user.domain.UserRole;
import com.codelab.micproject.account.user.repository.UserRepository;
import com.codelab.micproject.security.oauth2.userinfo.OAuth2UserInfo;
import com.codelab.micproject.security.oauth2.userinfo.UserInfoFactory;

import lombok.RequiredArgsConstructor;
import org.springframework.security.oauth2.client.userinfo.*;
import org.springframework.security.oauth2.core.*;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * 흐름:
 * 1) provider 식별(registrationId) -> OAuth2UserInfo로 표준화
 * 2) provider+providerId로 사용자 조회, 없으면 신규 가입
 * 3) 이메일 제공 시 email unique 유지 (정책에 따라 병합/충돌 처리)
 */
@Service
@RequiredArgsConstructor
public class CustomOAuth2UserService extends DefaultOAuth2UserService {

    private final UserRepository userRepository;

    @Override
    public OAuth2User loadUser(OAuth2UserRequest req) throws OAuth2AuthenticationException {
        OAuth2User oAuth2User = super.loadUser(req);
        String registrationId = req.getClientRegistration().getRegistrationId(); // "google", "kakao" 등
        AuthProvider provider = AuthProvider.valueOf(registrationId.toUpperCase());
        Map<String, Object> attributes = oAuth2User.getAttributes();

        OAuth2UserInfo info = UserInfoFactory.from(provider, attributes);
        if (info.getId() == null) throw new OAuth2AuthenticationException(new OAuth2Error("id_null"), "Provider id missing");

        // 1) provider+providerId 우선 조회
        User user = userRepository.findByProviderAndProviderId(provider, info.getId()).orElse(null);

        if (user == null) {
            // 2) 이메일이 있으면 이메일 중복 체크(정책 선택)
            String email = info.getEmail();
            if (email != null) {
                user = userRepository.findByEmail(email).orElse(null);
            }
        }

        if (user == null) {
            // 신규 가입
            user = User.builder()
                    .email(info.getEmail() != null ? info.getEmail() : "no-email-" + provider + "-" + info.getId() + "@placeholder.local")
                    .name(info.getName() != null ? info.getName() : provider.name() + "_user")
                    .password(null) // 소셜은 비밀번호 불필요
                    .role(UserRole.USER)
                    .provider(provider)
                    .providerId(info.getId())
                    .profileImage(info.getImageUrl())
                    .enabled(true)
                    .build();
        } else {
            // 기존 사용자 정보 보정(이름/이미지 갱신 등)
            if (user.getProvider() == null) user.setProvider(provider);
            if (user.getProviderId() == null) user.setProviderId(info.getId());
            if (info.getName() != null) user.setName(info.getName());
            if (info.getImageUrl() != null) user.setProfileImage(info.getImageUrl());
        }
        userRepository.save(user);
        return new UserPrincipal(user, attributes);
    }
}
